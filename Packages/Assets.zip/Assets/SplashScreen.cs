using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SplashScreen : MonoBehaviour
{
    public Image LOADINGBAR;


    private void Update()
    {
        LOADINGBAR.fillAmount += 0.0010f;

        if (LOADINGBAR.fillAmount == 1f)
        {
            nextscene();
        }

    }

    void nextscene ()
    {
        SceneManager.LoadScene(1);
    }


}

